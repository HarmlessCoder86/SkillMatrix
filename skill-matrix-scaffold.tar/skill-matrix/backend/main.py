"""
Skill Matrix API — FastAPI Backend
Run: uvicorn main:app --reload --port 8000
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional
from datetime import date
from uuid import UUID
import asyncpg
import os

# ─── CONFIG ───────────────────────────────────────────────────────────────────
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/skill_matrix")

app = FastAPI(title="Skill Matrix API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],  # Vite / CRA
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── DB POOL ──────────────────────────────────────────────────────────────────
pool: asyncpg.Pool = None

@app.on_event("startup")
async def startup():
    global pool
    pool = await asyncpg.create_pool(DATABASE_URL, min_size=2, max_size=10)

@app.on_event("shutdown")
async def shutdown():
    await pool.close()


# ─── MODELS ───────────────────────────────────────────────────────────────────

class AssessmentUpdate(BaseModel):
    status: str = Field(..., pattern="^(not_started|in_progress|competent|not_competent)$")
    score: Optional[float] = Field(None, ge=0, le=100)
    assessed_date: Optional[date] = None
    assessed_by: Optional[UUID] = None
    notes: Optional[str] = None

class AuditEntry(BaseModel):
    result: Optional[str] = Field(None, pattern="^(pass|fail)$")
    reason: Optional[str] = None
    notes: Optional[str] = None

class SkillCreate(BaseModel):
    category_id: UUID
    parent_skill_id: Optional[UUID] = None
    name: str
    description: Optional[str] = None
    sort_order: int = 0

class EmployeeCreate(BaseModel):
    name: str
    role: Optional[str] = None
    team_id: Optional[UUID] = None
    supervisor_id: Optional[UUID] = None
    avatar_url: Optional[str] = None

class SavedSearchCreate(BaseModel):
    name: str
    filters: dict


# ─── MATRIX ENDPOINT (the big one) ───────────────────────────────────────────

@app.get("/api/matrix")
async def get_matrix(
    team_id: Optional[UUID] = None,
    supervisor_id: Optional[UUID] = None,
):
    """
    Returns the full skill matrix payload:
    {
        employees: [{id, name, role, avatar_url, completion_pct}],
        categories: [{id, name, skills: [{id, name, parent_skill_id, children: [...]}]}],
        assessments: {"{employee_id}:{skill_id}": {status, score, assessed_date, notes}},
        category_completion: {"{employee_id}:{category_id}": pct}
    }
    """

    # ── Employees ──
    emp_query = "SELECT id, name, role, team_id, supervisor_id, avatar_url FROM employees WHERE is_active = TRUE"
    params = []
    if team_id:
        params.append(team_id)
        emp_query += f" AND team_id = ${len(params)}"
    if supervisor_id:
        params.append(supervisor_id)
        emp_query += f" AND supervisor_id = ${len(params)}"
    emp_query += " ORDER BY name"

    async with pool.acquire() as conn:
        employees = await conn.fetch(emp_query, *params)

        # ── Skill tree ──
        categories = await conn.fetch(
            "SELECT id, name, sort_order FROM skill_categories ORDER BY sort_order"
        )
        skills = await conn.fetch(
            "SELECT id, category_id, parent_skill_id, name, sort_order FROM skills WHERE is_active = TRUE ORDER BY sort_order"
        )

        # ── Assessments ──
        emp_ids = [e["id"] for e in employees]
        assessments_raw = []
        if emp_ids:
            assessments_raw = await conn.fetch(
                """SELECT employee_id, skill_id, status, score, assessed_date, notes
                   FROM assessments WHERE employee_id = ANY($1)""",
                emp_ids
            )

        # ── Category completion ──
        cat_completion_raw = []
        if emp_ids:
            cat_completion_raw = await conn.fetch(
                """SELECT employee_id, category_id, completion_pct
                   FROM v_category_completion WHERE employee_id = ANY($1)""",
                emp_ids
            )

        # ── Employee completion ──
        emp_completion_raw = []
        if emp_ids:
            emp_completion_raw = await conn.fetch(
                """SELECT employee_id, completion_pct FROM v_employee_completion WHERE employee_id = ANY($1)""",
                emp_ids
            )

    # ── Build response ──
    emp_completion = {str(r["employee_id"]): float(r["completion_pct"] or 0) for r in emp_completion_raw}

    emp_list = [
        {
            "id": str(e["id"]),
            "name": e["name"],
            "role": e["role"],
            "avatar_url": e["avatar_url"],
            "completion_pct": emp_completion.get(str(e["id"]), 0),
        }
        for e in employees
    ]

    # Build skill tree per category
    skills_by_cat = {}
    for s in skills:
        cat_id = str(s["category_id"])
        skills_by_cat.setdefault(cat_id, []).append(s)

    def build_tree(skill_list, parent_id=None):
        nodes = []
        for s in skill_list:
            s_parent = str(s["parent_skill_id"]) if s["parent_skill_id"] else None
            p_check = str(parent_id) if parent_id else None
            if s_parent == p_check:
                node = {
                    "id": str(s["id"]),
                    "name": s["name"],
                    "parent_skill_id": s_parent,
                    "children": build_tree(skill_list, s["id"]),
                }
                nodes.append(node)
        return nodes

    cat_list = []
    for c in categories:
        cid = str(c["id"])
        cat_skills = skills_by_cat.get(cid, [])
        cat_list.append({
            "id": cid,
            "name": c["name"],
            "skills": build_tree(cat_skills),
        })

    # Flat assessment lookup
    assessment_map = {}
    for a in assessments_raw:
        key = f"{a['employee_id']}:{a['skill_id']}"
        assessment_map[key] = {
            "status": a["status"],
            "score": float(a["score"]) if a["score"] is not None else None,
            "assessed_date": a["assessed_date"].isoformat() if a["assessed_date"] else None,
            "notes": a["notes"],
        }

    cat_comp_map = {}
    for r in cat_completion_raw:
        key = f"{r['employee_id']}:{r['category_id']}"
        cat_comp_map[key] = float(r["completion_pct"] or 0)

    return {
        "employees": emp_list,
        "categories": cat_list,
        "assessments": assessment_map,
        "category_completion": cat_comp_map,
    }


# ─── ASSESSMENT CRUD ─────────────────────────────────────────────────────────

@app.put("/api/assessments/{employee_id}/{skill_id}")
async def upsert_assessment(employee_id: UUID, skill_id: UUID, body: AssessmentUpdate):
    """Create or update an assessment. Returns the assessment record."""
    async with pool.acquire() as conn:
        # Get existing for audit
        existing = await conn.fetchrow(
            "SELECT id, status, score FROM assessments WHERE employee_id = $1 AND skill_id = $2",
            employee_id, skill_id
        )

        if existing:
            await conn.execute(
                """UPDATE assessments
                   SET status = $1, score = $2, assessed_date = $3, assessed_by = $4, notes = $5, updated_at = NOW()
                   WHERE employee_id = $6 AND skill_id = $7""",
                body.status, body.score, body.assessed_date, body.assessed_by, body.notes,
                employee_id, skill_id
            )
            # Audit log
            await conn.execute(
                """INSERT INTO assessment_audit (assessment_id, old_status, new_status, old_score, new_score)
                   VALUES ($1, $2, $3, $4, $5)""",
                existing["id"], existing["status"], body.status,
                existing["score"], body.score
            )
        else:
            await conn.execute(
                """INSERT INTO assessments (employee_id, skill_id, status, score, assessed_date, assessed_by, notes)
                   VALUES ($1, $2, $3, $4, $5, $6, $7)""",
                employee_id, skill_id, body.status, body.score, body.assessed_date,
                body.assessed_by, body.notes
            )

    return {"ok": True}


@app.get("/api/assessments/{employee_id}/{skill_id}")
async def get_assessment_detail(employee_id: UUID, skill_id: UUID):
    """Get full assessment detail + audit history for the detail panel."""
    async with pool.acquire() as conn:
        assessment = await conn.fetchrow(
            """SELECT a.*, e.name as assessor_name
               FROM assessments a
               LEFT JOIN employees e ON a.assessed_by = e.id
               WHERE a.employee_id = $1 AND a.skill_id = $2""",
            employee_id, skill_id
        )
        if not assessment:
            return {"assessment": None, "audit": []}

        audit = await conn.fetch(
            """SELECT * FROM assessment_audit
               WHERE assessment_id = $1 ORDER BY changed_at DESC""",
            assessment["id"]
        )

    return {
        "assessment": dict(assessment),
        "audit": [dict(a) for a in audit],
    }


# ─── EMPLOYEES ────────────────────────────────────────────────────────────────

@app.get("/api/employees")
async def list_employees(team_id: Optional[UUID] = None):
    async with pool.acquire() as conn:
        if team_id:
            rows = await conn.fetch(
                "SELECT * FROM employees WHERE is_active AND team_id = $1 ORDER BY name", team_id
            )
        else:
            rows = await conn.fetch("SELECT * FROM employees WHERE is_active ORDER BY name")
    return [dict(r) for r in rows]

@app.post("/api/employees")
async def create_employee(body: EmployeeCreate):
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            """INSERT INTO employees (name, role, team_id, supervisor_id, avatar_url)
               VALUES ($1, $2, $3, $4, $5) RETURNING *""",
            body.name, body.role, body.team_id, body.supervisor_id, body.avatar_url
        )
    return dict(row)


# ─── SKILLS ───────────────────────────────────────────────────────────────────

@app.get("/api/skills")
async def list_skills():
    async with pool.acquire() as conn:
        cats = await conn.fetch("SELECT * FROM skill_categories ORDER BY sort_order")
        skills = await conn.fetch("SELECT * FROM skills WHERE is_active ORDER BY sort_order")
    return {"categories": [dict(c) for c in cats], "skills": [dict(s) for s in skills]}

@app.post("/api/skills")
async def create_skill(body: SkillCreate):
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            """INSERT INTO skills (category_id, parent_skill_id, name, description, sort_order)
               VALUES ($1, $2, $3, $4, $5) RETURNING *""",
            body.category_id, body.parent_skill_id, body.name, body.description, body.sort_order
        )
    return dict(row)


# ─── TEAMS ────────────────────────────────────────────────────────────────────

@app.get("/api/teams")
async def list_teams():
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM teams ORDER BY name")
    return [dict(r) for r in rows]


# ─── SAVED SEARCHES ──────────────────────────────────────────────────────────

@app.get("/api/saved-searches")
async def list_saved_searches(owner_id: Optional[UUID] = None):
    async with pool.acquire() as conn:
        if owner_id:
            rows = await conn.fetch("SELECT * FROM saved_searches WHERE owner_id = $1", owner_id)
        else:
            rows = await conn.fetch("SELECT * FROM saved_searches")
    return [dict(r) for r in rows]

@app.post("/api/saved-searches")
async def create_saved_search(body: SavedSearchCreate):
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "INSERT INTO saved_searches (name, filters) VALUES ($1, $2) RETURNING *",
            body.name, body.filters
        )
    return dict(row)


# ─── HEALTH ───────────────────────────────────────────────────────────────────

@app.get("/api/health")
async def health():
    async with pool.acquire() as conn:
        await conn.fetchval("SELECT 1")
    return {"status": "ok"}
