-- =============================================================================
-- SKILL MATRIX v1 — DATABASE SCHEMA
-- =============================================================================
-- 5-level proficiency (0-4), gap analysis, assessment workflow, training tracking
-- Run: psql -U postgres -d skill_matrix -f schema.sql
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── ENUMS ───────────────────────────────────────────────────────────────────

CREATE TYPE submission_type AS ENUM ('self', 'peer', 'manager');
CREATE TYPE audit_result AS ENUM ('pass', 'fail');

-- ─── TEAMS ───────────────────────────────────────────────────────────────────

CREATE TABLE teams (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name        VARCHAR(100) NOT NULL,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─── EMPLOYEES ───────────────────────────────────────────────────────────────

CREATE TABLE employees (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(150) NOT NULL,
    role            VARCHAR(100),
    department      VARCHAR(100),
    team_id         UUID REFERENCES teams(id) ON DELETE SET NULL,
    supervisor_id   UUID REFERENCES employees(id) ON DELETE SET NULL,
    avatar_url      VARCHAR(500),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_employees_team ON employees(team_id);
CREATE INDEX idx_employees_supervisor ON employees(supervisor_id);
CREATE INDEX idx_employees_role ON employees(role);

-- ─── SKILL CATEGORIES ────────────────────────────────────────────────────────

CREATE TABLE skill_categories (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name        VARCHAR(150) NOT NULL,
    sort_order  INT DEFAULT 0,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─── SKILLS (hierarchical) ──────────────────────────────────────────────────

CREATE TABLE skills (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category_id             UUID NOT NULL REFERENCES skill_categories(id) ON DELETE CASCADE,
    parent_skill_id         UUID REFERENCES skills(id) ON DELETE CASCADE,
    name                    VARCHAR(200) NOT NULL,
    description             TEXT,
    sort_order              INT DEFAULT 0,
    retrain_interval_days   INT,
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_skills_category ON skills(category_id);
CREATE INDEX idx_skills_parent ON skills(parent_skill_id);

-- ─── TRAINING OWNERS ─────────────────────────────────────────────────────────

CREATE TABLE training_owners (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    skill_id    UUID NOT NULL REFERENCES skills(id) ON DELETE CASCADE UNIQUE,
    owner_id    UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─── ASSESSMENTS (current proficiency per employee × skill) ──────────────────

CREATE TABLE assessments (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id         UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    skill_id            UUID NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
    level               INT NOT NULL DEFAULT 0 CHECK (level >= 0 AND level <= 4),
    last_trained_date   DATE,
    retrain_due_date    DATE,
    approved_by         UUID REFERENCES employees(id),
    approved_at         TIMESTAMPTZ,
    notes               TEXT,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(employee_id, skill_id)
);

CREATE INDEX idx_assessments_employee ON assessments(employee_id);
CREATE INDEX idx_assessments_skill ON assessments(skill_id);
CREATE INDEX idx_assessments_overdue ON assessments(retrain_due_date) WHERE retrain_due_date IS NOT NULL;

-- ─── ASSESSMENT SUBMISSIONS ──────────────────────────────────────────────────

CREATE TABLE assessment_submissions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    assessment_id   UUID NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
    submitted_by    UUID NOT NULL REFERENCES employees(id),
    type            submission_type NOT NULL,
    level           INT NOT NULL CHECK (level >= 0 AND level <= 4),
    notes           TEXT,
    submitted_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_submissions_assessment ON assessment_submissions(assessment_id);

-- ─── ASSESSMENT AUDIT ────────────────────────────────────────────────────────

CREATE TABLE assessment_audit (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    assessment_id   UUID NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
    changed_by      UUID REFERENCES employees(id),
    old_level       INT,
    new_level       INT,
    reason          VARCHAR(200),
    result          audit_result,
    notes           TEXT,
    changed_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_audit_assessment ON assessment_audit(assessment_id);

-- ─── SKILL REQUIREMENTS — STAFFING COVERAGE ──────────────────────────────────

CREATE TABLE skill_requirements (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    skill_id            UUID NOT NULL REFERENCES skills(id) ON DELETE CASCADE UNIQUE,
    level_3_required    INT NOT NULL DEFAULT 0,
    level_4_required    INT NOT NULL DEFAULT 0
);

-- ─── ROLE SKILL REQUIREMENTS — INDIVIDUAL GAP ───────────────────────────────

CREATE TABLE role_skill_requirements (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    role_name       VARCHAR(100) NOT NULL,
    skill_id        UUID NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
    required_level  INT NOT NULL DEFAULT 0 CHECK (required_level >= 0 AND required_level <= 4),
    UNIQUE(role_name, skill_id)
);

CREATE INDEX idx_role_reqs_role ON role_skill_requirements(role_name);
CREATE INDEX idx_role_reqs_skill ON role_skill_requirements(skill_id);

-- ─── PEER ASSIGNMENTS ────────────────────────────────────────────────────────

CREATE TABLE peer_assignments (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    assessor_id     UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    assessee_id     UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    skill_id        UUID REFERENCES skills(id) ON DELETE CASCADE,
    assigned_by     UUID NOT NULL REFERENCES employees(id),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(assessor_id, assessee_id, skill_id)
);

CREATE INDEX idx_peer_assign_assessor ON peer_assignments(assessor_id);
CREATE INDEX idx_peer_assign_assessee ON peer_assignments(assessee_id);

-- ─── SAVED SEARCHES ──────────────────────────────────────────────────────────

CREATE TABLE saved_searches (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name        VARCHAR(100) NOT NULL,
    owner_id    UUID REFERENCES employees(id) ON DELETE CASCADE,
    filters     JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ DEFAULT NOW()
);


-- =============================================================================
-- VIEWS
-- =============================================================================

CREATE OR REPLACE VIEW v_employee_scores AS
SELECT
    e.id AS employee_id,
    e.name,
    e.role,
    e.team_id,
    COALESCE(SUM(a.level), 0) AS total_score,
    COUNT(s.id) AS total_skills,
    COUNT(a.id) FILTER (WHERE a.level > 0) AS assessed_count,
    ROUND(
        COALESCE(SUM(a.level), 0) * 100.0 / NULLIF(COUNT(s.id) * 4, 0), 1
    ) AS completion_pct
FROM employees e
CROSS JOIN skills s
LEFT JOIN assessments a ON a.employee_id = e.id AND a.skill_id = s.id
WHERE e.is_active AND s.is_active AND s.parent_skill_id IS NOT NULL
GROUP BY e.id, e.name, e.role, e.team_id;

CREATE OR REPLACE VIEW v_staffing_coverage AS
SELECT
    s.id AS skill_id,
    s.name AS skill_name,
    s.category_id,
    COALESCE(sr.level_3_required, 0) AS level_3_required,
    COALESCE(sr.level_4_required, 0) AS level_4_required,
    COUNT(a.id) FILTER (WHERE a.level >= 3) AS actual_level_3_plus,
    COUNT(a.id) FILTER (WHERE a.level = 4) AS actual_level_4,
    COUNT(a.id) FILTER (WHERE a.level >= 3) - COALESCE(sr.level_3_required, 0) AS level_3_gap,
    COUNT(a.id) FILTER (WHERE a.level = 4) - COALESCE(sr.level_4_required, 0) AS level_4_gap
FROM skills s
LEFT JOIN skill_requirements sr ON sr.skill_id = s.id
LEFT JOIN assessments a ON a.skill_id = s.id
LEFT JOIN employees e ON a.employee_id = e.id AND e.is_active
WHERE s.is_active
GROUP BY s.id, s.name, s.category_id, sr.level_3_required, sr.level_4_required;

CREATE OR REPLACE VIEW v_skill_level_distribution AS
SELECT
    s.id AS skill_id,
    COUNT(e.id) AS total_employees,
    COUNT(e.id) FILTER (WHERE COALESCE(a.level, 0) = 0) AS count_untrained,
    COUNT(e.id) FILTER (WHERE a.level = 1) AS count_level_1,
    COUNT(e.id) FILTER (WHERE a.level = 2) AS count_level_2,
    COUNT(e.id) FILTER (WHERE a.level = 3) AS count_level_3,
    COUNT(e.id) FILTER (WHERE a.level = 4) AS count_level_4
FROM skills s
CROSS JOIN employees e
LEFT JOIN assessments a ON a.skill_id = s.id AND a.employee_id = e.id
WHERE s.is_active AND e.is_active
GROUP BY s.id;

CREATE OR REPLACE VIEW v_overdue_retraining AS
SELECT
    a.id AS assessment_id,
    a.employee_id,
    e.name AS employee_name,
    a.skill_id,
    s.name AS skill_name,
    a.retrain_due_date,
    a.last_trained_date,
    a.level,
    CURRENT_DATE - a.retrain_due_date AS days_overdue
FROM assessments a
JOIN employees e ON a.employee_id = e.id
JOIN skills s ON a.skill_id = s.id
WHERE a.retrain_due_date IS NOT NULL
  AND a.retrain_due_date < CURRENT_DATE
  AND e.is_active
ORDER BY a.retrain_due_date ASC;

CREATE OR REPLACE VIEW v_individual_gaps AS
SELECT
    e.id AS employee_id,
    e.name AS employee_name,
    e.role,
    s.id AS skill_id,
    s.name AS skill_name,
    rsr.required_level,
    COALESCE(a.level, 0) AS actual_level,
    rsr.required_level - COALESCE(a.level, 0) AS gap,
    a.last_trained_date,
    a.retrain_due_date
FROM employees e
JOIN role_skill_requirements rsr ON rsr.role_name = e.role
JOIN skills s ON rsr.skill_id = s.id
LEFT JOIN assessments a ON a.employee_id = e.id AND a.skill_id = s.id
WHERE e.is_active AND s.is_active
  AND rsr.required_level > COALESCE(a.level, 0)
ORDER BY (rsr.required_level - COALESCE(a.level, 0)) DESC;

CREATE OR REPLACE VIEW v_category_completion AS
SELECT
    e.id AS employee_id,
    sc.id AS category_id,
    sc.name AS category_name,
    COUNT(s.id) AS total_skills,
    ROUND(
        COALESCE(SUM(COALESCE(a.level, 0)), 0) * 100.0 / NULLIF(COUNT(s.id) * 4, 0), 1
    ) AS completion_pct
FROM employees e
CROSS JOIN skills s
JOIN skill_categories sc ON s.category_id = sc.id
LEFT JOIN assessments a ON a.employee_id = e.id AND a.skill_id = s.id
WHERE e.is_active AND s.is_active AND s.parent_skill_id IS NOT NULL
GROUP BY e.id, sc.id, sc.name;


-- =============================================================================
-- SEED DATA
-- =============================================================================

INSERT INTO teams (id, name) VALUES
    ('a1000000-0000-0000-0000-000000000001', 'Area 1'),
    ('a1000000-0000-0000-0000-000000000002', 'Area 2'),
    ('a1000000-0000-0000-0000-000000000003', 'Area 3');

INSERT INTO employees (id, name, role, department, team_id) VALUES
    ('e1000000-0000-0000-0000-000000000001', 'Carlos Beck',       'Operator',     'Manufacturing', 'a1000000-0000-0000-0000-000000000001'),
    ('e1000000-0000-0000-0000-000000000002', 'Elena Dixon',       'Operator',     'Manufacturing', 'a1000000-0000-0000-0000-000000000001'),
    ('e1000000-0000-0000-0000-000000000003', 'Holly Harrington',  'Operator',     'Manufacturing', 'a1000000-0000-0000-0000-000000000001'),
    ('e1000000-0000-0000-0000-000000000004', 'Mark Hull',         'Operator',     'Manufacturing', 'a1000000-0000-0000-0000-000000000001'),
    ('e1000000-0000-0000-0000-000000000005', 'Luke Hatton',       'Operator',     'Manufacturing', 'a1000000-0000-0000-0000-000000000002'),
    ('e1000000-0000-0000-0000-000000000006', 'Pedro Jensen',      'Technician',   'Manufacturing', 'a1000000-0000-0000-0000-000000000002'),
    ('e1000000-0000-0000-0000-000000000007', 'Grace Joseph',      'Technician',   'Manufacturing', 'a1000000-0000-0000-0000-000000000002'),
    ('e1000000-0000-0000-0000-000000000008', 'Timothy Mack',      'Lead',         'Manufacturing', 'a1000000-0000-0000-0000-000000000002'),
    ('e1000000-0000-0000-0000-000000000009', 'Hannah Maxwell',    'Operator',     'Manufacturing', 'a1000000-0000-0000-0000-000000000003'),
    ('e1000000-0000-0000-0000-000000000010', 'Joey Rivera',       'Operator',     'Manufacturing', 'a1000000-0000-0000-0000-000000000003'),
    ('e1000000-0000-0000-0000-000000000011', 'Gilbert Ross',      'Operator',     'Manufacturing', 'a1000000-0000-0000-0000-000000000003'),
    ('e1000000-0000-0000-0000-000000000012', 'Tammy Sanchez',     'Operator',     'Manufacturing', 'a1000000-0000-0000-0000-000000000001'),
    ('e1000000-0000-0000-0000-000000000013', 'Kurt Lyons',        'Technician',   'Manufacturing', 'a1000000-0000-0000-0000-000000000002'),
    ('e1000000-0000-0000-0000-000000000014', 'Beth Austin',       'Lead',         'Manufacturing', 'a1000000-0000-0000-0000-000000000001');

INSERT INTO skill_categories (id, name, sort_order) VALUES
    ('c1000000-0000-0000-0000-000000000001', 'Site Safety', 1),
    ('c1000000-0000-0000-0000-000000000002', 'Assembly Line A', 2);

INSERT INTO skills (id, category_id, parent_skill_id, name, sort_order, retrain_interval_days) VALUES
    ('s1000000-0000-0000-0000-000000000001', 'c1000000-0000-0000-0000-000000000001', NULL, 'Fire & Emergency Procedures', 1, 365),
    ('s1000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000001', NULL, 'Hazardous Material Handling', 2, 365),
    ('s1000000-0000-0000-0000-000000000003', 'c1000000-0000-0000-0000-000000000001', NULL, 'HSE Site Induction', 3, NULL),
    ('s1000000-0000-0000-0000-000000000004', 'c1000000-0000-0000-0000-000000000001', NULL, 'Machine Safety Protocols', 4, 180),
    ('s1000000-0000-0000-0000-000000000005', 'c1000000-0000-0000-0000-000000000001', NULL, 'PPE Compliance', 5, 365),
    ('s1000000-0000-0000-0000-000000000006', 'c1000000-0000-0000-0000-000000000001', NULL, 'Lockout/Tagout (LOTO)', 6, 365),
    ('s1000000-0000-0000-0000-000000000010', 'c1000000-0000-0000-0000-000000000002', NULL, 'Station 1 — Frame Assembly', 1, NULL),
    ('s1000000-0000-0000-0000-000000000011', 'c1000000-0000-0000-0000-000000000002', NULL, 'Station 2 — Weld & Fasten', 2, NULL),
    ('s1000000-0000-0000-0000-000000000012', 'c1000000-0000-0000-0000-000000000002', 's1000000-0000-0000-0000-000000000011', 'MIG Welding', 1, 365),
    ('s1000000-0000-0000-0000-000000000013', 'c1000000-0000-0000-0000-000000000002', 's1000000-0000-0000-0000-000000000011', 'Torque Fastening', 2, NULL),
    ('s1000000-0000-0000-0000-000000000014', 'c1000000-0000-0000-0000-000000000002', NULL, 'Station 3 — Quality Check', 3, NULL),
    ('s1000000-0000-0000-0000-000000000015', 'c1000000-0000-0000-0000-000000000002', NULL, 'Station 4 — Pack & Ship', 4, NULL);

INSERT INTO skill_requirements (skill_id, level_3_required, level_4_required) VALUES
    ('s1000000-0000-0000-0000-000000000001', 5, 2),
    ('s1000000-0000-0000-0000-000000000002', 3, 1),
    ('s1000000-0000-0000-0000-000000000004', 4, 1),
    ('s1000000-0000-0000-0000-000000000010', 3, 1),
    ('s1000000-0000-0000-0000-000000000012', 3, 2),
    ('s1000000-0000-0000-0000-000000000014', 4, 2);

INSERT INTO role_skill_requirements (role_name, skill_id, required_level) VALUES
    ('Operator',    's1000000-0000-0000-0000-000000000001', 3),
    ('Operator',    's1000000-0000-0000-0000-000000000002', 2),
    ('Operator',    's1000000-0000-0000-0000-000000000003', 3),
    ('Operator',    's1000000-0000-0000-0000-000000000004', 3),
    ('Operator',    's1000000-0000-0000-0000-000000000005', 3),
    ('Operator',    's1000000-0000-0000-0000-000000000006', 2),
    ('Operator',    's1000000-0000-0000-0000-000000000010', 2),
    ('Technician',  's1000000-0000-0000-0000-000000000001', 3),
    ('Technician',  's1000000-0000-0000-0000-000000000002', 3),
    ('Technician',  's1000000-0000-0000-0000-000000000003', 3),
    ('Technician',  's1000000-0000-0000-0000-000000000004', 4),
    ('Technician',  's1000000-0000-0000-0000-000000000005', 3),
    ('Technician',  's1000000-0000-0000-0000-000000000006', 3),
    ('Technician',  's1000000-0000-0000-0000-000000000012', 3),
    ('Lead',        's1000000-0000-0000-0000-000000000001', 4),
    ('Lead',        's1000000-0000-0000-0000-000000000002', 4),
    ('Lead',        's1000000-0000-0000-0000-000000000003', 4),
    ('Lead',        's1000000-0000-0000-0000-000000000004', 4),
    ('Lead',        's1000000-0000-0000-0000-000000000005', 4),
    ('Lead',        's1000000-0000-0000-0000-000000000006', 4),
    ('Lead',        's1000000-0000-0000-0000-000000000012', 4);

INSERT INTO training_owners (skill_id, owner_id) VALUES
    ('s1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000014'),
    ('s1000000-0000-0000-0000-000000000004', 'e1000000-0000-0000-0000-000000000008'),
    ('s1000000-0000-0000-0000-000000000012', 'e1000000-0000-0000-0000-000000000008');

INSERT INTO assessments (employee_id, skill_id, level, last_trained_date, retrain_due_date) VALUES
    ('e1000000-0000-0000-0000-000000000001', 's1000000-0000-0000-0000-000000000001', 4, '2025-01-15', '2026-01-15'),
    ('e1000000-0000-0000-0000-000000000001', 's1000000-0000-0000-0000-000000000002', 3, '2025-01-15', '2026-01-15'),
    ('e1000000-0000-0000-0000-000000000001', 's1000000-0000-0000-0000-000000000003', 3, '2025-01-10', NULL),
    ('e1000000-0000-0000-0000-000000000001', 's1000000-0000-0000-0000-000000000004', 2, '2024-09-01', '2025-03-01'),
    ('e1000000-0000-0000-0000-000000000001', 's1000000-0000-0000-0000-000000000005', 3, '2025-02-01', '2026-02-01'),
    ('e1000000-0000-0000-0000-000000000001', 's1000000-0000-0000-0000-000000000010', 2, '2025-03-01', NULL),
    ('e1000000-0000-0000-0000-000000000001', 's1000000-0000-0000-0000-000000000012', 1, '2025-02-15', '2026-02-15'),
    ('e1000000-0000-0000-0000-000000000002', 's1000000-0000-0000-0000-000000000001', 2, '2025-06-01', '2026-06-01'),
    ('e1000000-0000-0000-0000-000000000002', 's1000000-0000-0000-0000-000000000002', 1, '2025-06-01', '2026-06-01'),
    ('e1000000-0000-0000-0000-000000000002', 's1000000-0000-0000-0000-000000000003', 2, '2025-06-01', NULL),
    ('e1000000-0000-0000-0000-000000000002', 's1000000-0000-0000-0000-000000000005', 1, '2025-06-15', '2026-06-15'),
    ('e1000000-0000-0000-0000-000000000008', 's1000000-0000-0000-0000-000000000001', 4, '2024-11-01', '2025-11-01'),
    ('e1000000-0000-0000-0000-000000000008', 's1000000-0000-0000-0000-000000000002', 4, '2024-11-01', '2025-11-01'),
    ('e1000000-0000-0000-0000-000000000008', 's1000000-0000-0000-0000-000000000003', 4, '2024-11-01', NULL),
    ('e1000000-0000-0000-0000-000000000008', 's1000000-0000-0000-0000-000000000004', 4, '2024-11-01', '2025-05-01'),
    ('e1000000-0000-0000-0000-000000000008', 's1000000-0000-0000-0000-000000000005', 4, '2024-11-01', '2025-11-01'),
    ('e1000000-0000-0000-0000-000000000008', 's1000000-0000-0000-0000-000000000006', 4, '2024-11-01', '2025-11-01'),
    ('e1000000-0000-0000-0000-000000000008', 's1000000-0000-0000-0000-000000000010', 4, '2024-12-01', NULL),
    ('e1000000-0000-0000-0000-000000000008', 's1000000-0000-0000-0000-000000000012', 4, '2024-12-01', '2025-12-01'),
    ('e1000000-0000-0000-0000-000000000008', 's1000000-0000-0000-0000-000000000013', 4, '2024-12-01', NULL),
    ('e1000000-0000-0000-0000-000000000008', 's1000000-0000-0000-0000-000000000014', 4, '2024-12-01', NULL),
    ('e1000000-0000-0000-0000-000000000008', 's1000000-0000-0000-0000-000000000015', 4, '2024-12-01', NULL),
    ('e1000000-0000-0000-0000-000000000003', 's1000000-0000-0000-0000-000000000001', 3, '2025-02-01', '2026-02-01'),
    ('e1000000-0000-0000-0000-000000000003', 's1000000-0000-0000-0000-000000000003', 3, '2025-02-01', NULL),
    ('e1000000-0000-0000-0000-000000000003', 's1000000-0000-0000-0000-000000000005', 2, '2025-02-01', '2026-02-01'),
    ('e1000000-0000-0000-0000-000000000003', 's1000000-0000-0000-0000-000000000010', 3, '2025-03-15', NULL),
    ('e1000000-0000-0000-0000-000000000006', 's1000000-0000-0000-0000-000000000001', 3, '2025-01-20', '2026-01-20'),
    ('e1000000-0000-0000-0000-000000000006', 's1000000-0000-0000-0000-000000000002', 3, '2025-01-20', '2026-01-20'),
    ('e1000000-0000-0000-0000-000000000006', 's1000000-0000-0000-0000-000000000003', 3, '2025-01-20', NULL),
    ('e1000000-0000-0000-0000-000000000006', 's1000000-0000-0000-0000-000000000004', 3, '2025-01-20', '2025-07-20'),
    ('e1000000-0000-0000-0000-000000000006', 's1000000-0000-0000-0000-000000000012', 3, '2025-02-01', '2026-02-01');
