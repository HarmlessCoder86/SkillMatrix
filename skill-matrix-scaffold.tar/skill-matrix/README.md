# Skill Matrix

Frontline skills management tool — tracks employee competency across hierarchical skill categories.

## Architecture

```
frontend/          React + Vite + Tailwind
  src/
    components/    MatrixGrid, FilterBar, DetailPanel, StatusIcon
    hooks/         useMatrix (data fetching)
    lib/           api.js (REST client)
    pages/         (future: separate routes)

backend/           FastAPI + asyncpg
  main.py          API server (all endpoints)
  schema.sql       Postgres schema + seed data
```

## Setup

### 1. Database

```bash
createdb skill_matrix
psql -d skill_matrix -f backend/schema.sql
```

### 2. Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Set `DATABASE_URL` env var if not using default `postgres:postgres@localhost:5432/skill_matrix`.

### 3. Frontend

```bash
cd frontend
npm install
npm run dev
```

Vite proxies `/api` → `localhost:8000` automatically.

Open `http://localhost:5173`.

## Data Model

| Table               | Purpose                                           |
|---------------------|---------------------------------------------------|
| `teams`             | Organizational grouping                           |
| `employees`         | Workers, with team + supervisor references         |
| `skill_categories`  | Top-level groupings (Site Safety, Machining, etc.) |
| `skills`            | Hierarchical via `parent_skill_id`                |
| `assessments`       | Employee × Skill junction with status/score        |
| `assessment_audit`  | Change log with pass/fail + reason                 |
| `saved_searches`    | Stored filter configs (JSONB)                      |

### Key Views

- `v_skill_matrix` — full cross-join of employees × skills with assessment status
- `v_employee_completion` — overall % complete per employee (leaf skills only)
- `v_category_completion` — % complete per employee per category

## API Endpoints

| Method | Path                                    | Description                    |
|--------|-----------------------------------------|--------------------------------|
| GET    | `/api/matrix?team_id=&supervisor_id=`   | Full matrix payload            |
| GET    | `/api/assessments/{emp}/{skill}`        | Detail + audit history         |
| PUT    | `/api/assessments/{emp}/{skill}`        | Create/update assessment       |
| GET    | `/api/employees`                        | List employees                 |
| POST   | `/api/employees`                        | Create employee                |
| GET    | `/api/skills`                           | List categories + skills       |
| POST   | `/api/skills`                           | Create skill                   |
| GET    | `/api/teams`                            | List teams                     |
| GET    | `/api/saved-searches`                   | List saved filters             |
| POST   | `/api/saved-searches`                   | Store a filter config          |

## What's Stubbed vs. Done

**Done (ready to use):**
- Full Postgres schema with views and seed data
- Complete REST API with all CRUD + matrix endpoint
- Matrix grid with collapsible skill tree, employee headers, status icons
- Assessment detail panel with edit form + audit history
- Team filter dropdown
- Vite + Tailwind configured

**Stubbed (needs implementation):**
- Proficiency / Experience / Assignment tab views (FilterBar has buttons, no logic)
- Saved Searches UI (button exists, modal/dropdown needed)
- Search filtering (input exists, client-side filter needed)
- Avatar upload / image handling
- CSV/Excel export
- Role-based access control
- Direct reports filter (supervisor_id param wired in API, not in UI dropdown yet)

## Deployment (DigitalOcean Droplet)

### Prerequisites
- Ubuntu 24.04 droplet ($24/mo — 2 vCPU, 4GB RAM)
- Domain with A record pointing to droplet IP (e.g., `skills.yourdomain.com → 123.45.67.89`)

### Steps

```bash
# 1. SSH into droplet
ssh root@your-droplet-ip

# 2. Clone the repo
git clone https://github.com/YOU/skill-matrix.git /opt/skill-matrix
cd /opt/skill-matrix

# 3. Run deploy script (installs Docker, configures firewall, sets up swap)
chmod +x deploy.sh
./deploy.sh

# 4. Configure environment
cp .env.example .env
nano .env    # Set DOMAIN and POSTGRES_PASSWORD

# 5. Launch
docker compose up -d
```

Caddy auto-provisions SSL via Let's Encrypt. Your app will be live at `https://skills.yourdomain.com` within ~30 seconds.

### Architecture on Droplet

```
Internet → Caddy (:443) → /api/*  → FastAPI (:8000) → Postgres (:5432)
                         → /*     → Nginx (:80, static React build)
```

All internal services bind to `127.0.0.1` only — Caddy is the only public-facing port.

### Common Commands

```bash
docker compose logs -f              # Watch all logs
docker compose logs -f api          # API logs only
docker compose exec db psql -U skillmatrix skill_matrix   # DB shell
docker compose down                 # Stop
docker compose up -d --build        # Rebuild & restart
```

### Backups

```bash
# Dump database
docker compose exec db pg_dump -U skillmatrix skill_matrix > backup_$(date +%Y%m%d).sql

# Restore
cat backup_20260318.sql | docker compose exec -T db psql -U skillmatrix skill_matrix
```

## Future Enhancements

- Drag-and-drop skill reordering
- Bulk assessment import (CSV upload)
- Email notifications for expiring certifications
- Dashboard view with gap analysis charts
- Print-friendly matrix view
