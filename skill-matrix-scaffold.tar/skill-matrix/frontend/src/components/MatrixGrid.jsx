import { useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';
import StatusIcon from './StatusIcon';

export default function MatrixGrid({
  employees,
  categories,
  assessments,
  categoryCompletion,
  onCellClick,
  selectedCell,
}) {
  const [collapsed, setCollapsed] = useState({}); // {categoryId: bool, skillId: bool}

  const toggleCollapse = (id) => {
    setCollapsed((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  /** Get assessment for an employee+skill */
  const getStatus = (empId, skillId) => {
    const key = `${empId}:${skillId}`;
    return assessments[key]?.status || 'not_started';
  };

  const getScore = (empId, skillId) => {
    const key = `${empId}:${skillId}`;
    return assessments[key]?.score;
  };

  const getCatCompletion = (empId, catId) => {
    const key = `${empId}:${catId}`;
    return categoryCompletion[key] ?? null;
  };

  /** Flatten skill tree into renderable rows */
  const flattenSkills = (skills, depth = 0, parentCollapsed = false) => {
    const rows = [];
    for (const skill of skills) {
      const hasChildren = skill.children && skill.children.length > 0;
      const isCollapsed = collapsed[skill.id];

      rows.push({
        id: skill.id,
        name: skill.name,
        depth,
        hasChildren,
        isCollapsed,
        hidden: parentCollapsed,
      });

      if (hasChildren) {
        rows.push(...flattenSkills(skill.children, depth + 1, parentCollapsed || isCollapsed));
      }
    }
    return rows;
  };

  const isSelected = (empId, skillId) =>
    selectedCell?.employeeId === empId && selectedCell?.skillId === skillId;

  // Fixed column width for employee columns
  const empColWidth = 100; // px
  const skillColWidth = 280; // px

  return (
    <div className="bg-white rounded-xl shadow-sm border border-matrix-border overflow-hidden">
      <div className="overflow-x-auto matrix-scroll">
        <table className="w-full border-collapse" style={{ minWidth: skillColWidth + employees.length * empColWidth }}>
          {/* ─── Employee Header Row ─── */}
          <thead>
            <tr className="bg-slate-50 border-b-2 border-matrix-border">
              {/* Skill name column header */}
              <th
                className="sticky left-0 z-20 bg-slate-50 text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider border-r border-matrix-border"
                style={{ minWidth: skillColWidth }}
              >
                Skills
              </th>
              {/* Employee columns */}
              {employees.map((emp) => (
                <th
                  key={emp.id}
                  className="px-2 py-3 text-center border-r border-matrix-border"
                  style={{ minWidth: empColWidth }}
                >
                  <div className="flex flex-col items-center gap-1">
                    {/* Avatar placeholder */}
                    <div className="w-8 h-8 rounded-full bg-slate-300 flex items-center justify-center text-xs font-bold text-white uppercase">
                      {emp.name.split(' ').map((n) => n[0]).join('')}
                    </div>
                    <span className="text-xs font-medium text-slate-700 leading-tight truncate max-w-[90px]">
                      {emp.name}
                    </span>
                    {/* Completion % */}
                    <span className="text-[10px] text-slate-400">
                      {emp.completion_pct?.toFixed(0) ?? 0}%
                    </span>
                  </div>
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {categories.map((category) => {
              const catCollapsed = collapsed[category.id];
              const skillRows = flattenSkills(category.skills);

              return (
                <CategoryBlock
                  key={category.id}
                  category={category}
                  catCollapsed={catCollapsed}
                  onToggle={() => toggleCollapse(category.id)}
                  skillRows={skillRows}
                  employees={employees}
                  getStatus={getStatus}
                  getScore={getScore}
                  getCatCompletion={getCatCompletion}
                  onCellClick={onCellClick}
                  onToggleSkill={toggleCollapse}
                  isSelected={isSelected}
                  skillColWidth={skillColWidth}
                />
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/** Category header row + its skill rows */
function CategoryBlock({
  category,
  catCollapsed,
  onToggle,
  skillRows,
  employees,
  getStatus,
  getScore,
  getCatCompletion,
  onCellClick,
  onToggleSkill,
  isSelected,
  skillColWidth,
}) {
  return (
    <>
      {/* Category header row */}
      <tr className="bg-slate-100 border-b border-matrix-border">
        <td
          className="sticky left-0 z-10 bg-slate-100 px-4 py-2 border-r border-matrix-border cursor-pointer select-none"
          style={{ minWidth: skillColWidth }}
          onClick={onToggle}
        >
          <div className="flex items-center gap-2">
            {catCollapsed ? (
              <ChevronRight size={16} className="text-slate-400" />
            ) : (
              <ChevronDown size={16} className="text-slate-400" />
            )}
            <span className="text-sm font-semibold text-slate-700">{category.name}</span>
          </div>
        </td>
        {/* Category completion per employee */}
        {employees.map((emp) => {
          const pct = getCatCompletion(emp.id, category.id);
          return (
            <td
              key={emp.id}
              className="px-2 py-2 text-center border-r border-matrix-border"
            >
              {pct !== null && (
                <span
                  className={`text-xs font-semibold ${
                    pct >= 100 ? 'text-matrix-competent' : pct > 0 ? 'text-matrix-in-progress' : 'text-slate-400'
                  }`}
                >
                  {pct.toFixed(0)}%
                </span>
              )}
            </td>
          );
        })}
      </tr>

      {/* Skill rows */}
      {!catCollapsed &&
        skillRows
          .filter((row) => !row.hidden)
          .map((row) => (
            <tr
              key={row.id}
              className="border-b border-matrix-border hover:bg-blue-50/30 transition-colors"
            >
              {/* Skill name with indentation */}
              <td
                className="sticky left-0 z-10 bg-white hover:bg-blue-50/30 px-4 py-2 border-r border-matrix-border"
                style={{ minWidth: skillColWidth }}
              >
                <div
                  className="flex items-center gap-1.5"
                  style={{ paddingLeft: `${row.depth * 20 + (row.hasChildren ? 0 : 20)}px` }}
                >
                  {row.hasChildren && (
                    <button
                      onClick={() => onToggleSkill(row.id)}
                      className="p-0.5 hover:bg-slate-200 rounded"
                    >
                      {row.isCollapsed ? (
                        <ChevronRight size={14} className="text-slate-400" />
                      ) : (
                        <ChevronDown size={14} className="text-slate-400" />
                      )}
                    </button>
                  )}
                  <span className={`text-sm ${row.hasChildren ? 'font-medium text-slate-600' : 'text-slate-600'}`}>
                    {row.name}
                  </span>
                </div>
              </td>

              {/* Assessment cells */}
              {employees.map((emp) => {
                const status = getStatus(emp.id, row.id);
                const score = getScore(emp.id, row.id);
                const selected = isSelected(emp.id, row.id);

                return (
                  <td
                    key={emp.id}
                    className={`px-2 py-2 text-center border-r border-matrix-border cursor-pointer transition-colors
                      ${selected ? 'bg-blue-100 ring-2 ring-blue-400 ring-inset' : 'hover:bg-blue-50'}`}
                    onClick={() => onCellClick(emp.id, row.id)}
                    title={`${emp.name} — ${row.name}: ${status}${score != null ? ` (${score}%)` : ''}`}
                  >
                    <div className="flex items-center justify-center">
                      <StatusIcon status={status} />
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
    </>
  );
}
