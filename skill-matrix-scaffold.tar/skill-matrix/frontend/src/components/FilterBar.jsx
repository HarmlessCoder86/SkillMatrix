import { useState, useEffect } from 'react';
import { Search, Filter, Bookmark } from 'lucide-react';
import { api } from '../lib/api';

export default function FilterBar({ filters, onChange }) {
  const [teams, setTeams] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    api.getTeams().then(setTeams).catch(console.error);
  }, []);

  const handleTeamChange = (e) => {
    const val = e.target.value;
    onChange({ ...filters, team_id: val || undefined });
  };

  return (
    <div className="bg-white border-b border-matrix-border px-6 py-3">
      <div className="flex items-center gap-4 flex-wrap">
        {/* Search */}
        <div className="relative flex-1 max-w-xs">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search skills or employees..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent"
          />
        </div>

        {/* Team filter */}
        <div className="flex items-center gap-2">
          <Filter size={16} className="text-slate-400" />
          <select
            value={filters.team_id || ''}
            onChange={handleTeamChange}
            className="text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
          >
            <option value="">All Teams</option>
            {teams.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        </div>

        {/* View tabs (placeholder — wire up as needed) */}
        <div className="flex items-center gap-1 bg-slate-100 rounded-lg p-0.5">
          {['Matrix', 'Proficiency', 'Experience', 'Assignment'].map((tab, i) => (
            <button
              key={tab}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                i === 0 ? 'bg-white text-slate-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Saved Searches */}
        <button className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 ml-auto">
          <Bookmark size={14} />
          Saved Searches
        </button>
      </div>
    </div>
  );
}
