import { useState, useEffect } from 'react';
import { X, Save, History } from 'lucide-react';
import { api } from '../lib/api';
import StatusIcon from './StatusIcon';

const STATUSES = [
  { value: 'not_started', label: 'Not Started' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'competent', label: 'Competent' },
  { value: 'not_competent', label: 'Not Competent' },
];

export default function DetailPanel({ employeeId, skillId, employees, onClose, onSaved }) {
  const [detail, setDetail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Form state
  const [status, setStatus] = useState('not_started');
  const [score, setScore] = useState('');
  const [notes, setNotes] = useState('');
  const [assessedDate, setAssessedDate] = useState('');

  useEffect(() => {
    setLoading(true);
    api
      .getAssessmentDetail(employeeId, skillId)
      .then((data) => {
        setDetail(data);
        if (data.assessment) {
          setStatus(data.assessment.status);
          setScore(data.assessment.score ?? '');
          setNotes(data.assessment.notes ?? '');
          setAssessedDate(data.assessment.assessed_date?.split('T')[0] ?? '');
        } else {
          setStatus('not_started');
          setScore('');
          setNotes('');
          setAssessedDate('');
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [employeeId, skillId]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await api.updateAssessment(employeeId, skillId, {
        status,
        score: score !== '' ? parseFloat(score) : null,
        assessed_date: assessedDate || null,
        notes: notes || null,
      });
      onSaved?.();
    } catch (err) {
      console.error('Save failed:', err);
    } finally {
      setSaving(false);
    }
  };

  const employee = employees.find((e) => e.id === employeeId);

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/20 z-40" onClick={onClose} />

      {/* Panel */}
      <div className="fixed right-0 top-0 bottom-0 w-[420px] bg-white shadow-2xl z-50 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-matrix-border">
          <div>
            <h2 className="text-base font-semibold text-slate-800">Assessment Detail</h2>
            {employee && (
              <p className="text-sm text-slate-500 mt-0.5">{employee.name}</p>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X size={18} className="text-slate-400" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
          {loading ? (
            <div className="text-center text-slate-400 py-10">Loading...</div>
          ) : (
            <>
              {/* Status selector */}
              <div>
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Status
                </label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {STATUSES.map((s) => (
                    <button
                      key={s.value}
                      onClick={() => setStatus(s.value)}
                      className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border text-sm transition-colors ${
                        status === s.value
                          ? 'border-blue-400 bg-blue-50 text-blue-700'
                          : 'border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <StatusIcon status={s.value} size={16} />
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Score */}
              <div>
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Score (%)
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={score}
                  onChange={(e) => setScore(e.target.value)}
                  placeholder="—"
                  className="w-full mt-1.5 px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
              </div>

              {/* Date */}
              <div>
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Assessment Date
                </label>
                <input
                  type="date"
                  value={assessedDate}
                  onChange={(e) => setAssessedDate(e.target.value)}
                  className="w-full mt-1.5 px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
              </div>

              {/* Notes */}
              <div>
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Notes
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Assessment notes..."
                  className="w-full mt-1.5 px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 resize-none"
                />
              </div>

              {/* Audit History */}
              {detail?.audit?.length > 0 && (
                <div>
                  <div className="flex items-center gap-1.5 mb-2">
                    <History size={14} className="text-slate-400" />
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                      History
                    </span>
                  </div>
                  <div className="space-y-2">
                    {detail.audit.map((entry, i) => (
                      <div
                        key={i}
                        className="bg-slate-50 rounded-lg px-3 py-2 text-xs text-slate-600"
                      >
                        <div className="flex items-center justify-between">
                          <span>
                            {entry.old_status} → {entry.new_status}
                          </span>
                          <span className="text-slate-400">
                            {new Date(entry.changed_at).toLocaleDateString()}
                          </span>
                        </div>
                        {entry.reason && (
                          <div className="mt-1 text-slate-500">Reason: {entry.reason}</div>
                        )}
                        {entry.result && (
                          <span
                            className={`inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                              entry.result === 'pass'
                                ? 'bg-green-100 text-green-700'
                                : 'bg-red-100 text-red-700'
                            }`}
                          >
                            {entry.result}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-matrix-border">
          <button
            onClick={handleSave}
            disabled={saving}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
          >
            <Save size={16} />
            {saving ? 'Saving...' : 'Save Assessment'}
          </button>
        </div>
      </div>
    </>
  );
}
