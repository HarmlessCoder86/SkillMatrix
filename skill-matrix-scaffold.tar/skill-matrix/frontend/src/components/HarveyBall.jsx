/**
 * HarveyBall — SVG circle filled proportionally to proficiency level.
 *
 * Level 0: Empty circle (Untrained)
 * Level 1: Quarter fill
 * Level 2: Half fill
 * Level 3: Three-quarter fill
 * Level 4: Full fill
 *
 * Props:
 *   level       (0-4) current proficiency
 *   required    (0-4, optional) required level for this role — shows gap ring
 *   overdue     (bool) if retrain is overdue — shows red dot
 *   size        (number) diameter in px, default 24
 *   onClick     (fn) click handler
 *   className   (string) additional classes
 */

const LEVEL_LABELS = [
  'Untrained',
  'Level 1 — TWI Received',
  'Level 2 — Minimal Supervision',
  'Level 3 — Independent',
  'Level 4 — Mastery',
];

// Colors
const FILL_COLOR = '#1e293b';    // slate-800
const STROKE_COLOR = '#64748b';  // slate-500
const GAP_COLOR = '#ef4444';     // red-500
const OVERDUE_COLOR = '#ef4444'; // red-500

/**
 * Generate SVG arc path for a filled wedge.
 * Fraction: 0 = empty, 0.25 = quarter, 0.5 = half, 0.75 = three-quarter, 1 = full
 */
function wedgePath(cx, cy, r, fraction) {
  if (fraction <= 0) return '';
  if (fraction >= 1) {
    // Full circle
    return `M ${cx} ${cy} m -${r} 0 a ${r} ${r} 0 1 1 ${r * 2} 0 a ${r} ${r} 0 1 1 -${r * 2} 0`;
  }

  const startAngle = -Math.PI / 2; // 12 o'clock
  const endAngle = startAngle + 2 * Math.PI * fraction;

  const x1 = cx + r * Math.cos(startAngle);
  const y1 = cy + r * Math.sin(startAngle);
  const x2 = cx + r * Math.cos(endAngle);
  const y2 = cy + r * Math.sin(endAngle);

  const largeArc = fraction > 0.5 ? 1 : 0;

  return `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`;
}

export default function HarveyBall({
  level = 0,
  required,
  overdue = false,
  size = 24,
  onClick,
  className = '',
}) {
  const cx = size / 2;
  const cy = size / 2;
  const r = size / 2 - 2; // Leave room for stroke
  const fraction = level / 4;
  const hasGap = required != null && level < required;
  const label = LEVEL_LABELS[level] || 'Unknown';

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      onClick={onClick}
      className={`inline-block ${onClick ? 'cursor-pointer' : ''} ${className}`}
      role="img"
      aria-label={`${label}${hasGap ? ` (required: ${LEVEL_LABELS[required]})` : ''}${overdue ? ' — OVERDUE' : ''}`}
    >
      {/* Background circle */}
      <circle
        cx={cx}
        cy={cy}
        r={r}
        fill="white"
        stroke={hasGap ? GAP_COLOR : STROKE_COLOR}
        strokeWidth={hasGap ? 2 : 1.5}
        strokeDasharray={hasGap ? '3 2' : 'none'}
      />

      {/* Filled wedge */}
      {level > 0 && (
        <path
          d={wedgePath(cx, cy, r, fraction)}
          fill={FILL_COLOR}
        />
      )}

      {/* Outline on top of fill for clean edge */}
      <circle
        cx={cx}
        cy={cy}
        r={r}
        fill="none"
        stroke={hasGap ? GAP_COLOR : STROKE_COLOR}
        strokeWidth={hasGap ? 2 : 1.5}
        strokeDasharray={hasGap ? '3 2' : 'none'}
      />

      {/* Overdue indicator — small red dot top-right */}
      {overdue && (
        <circle
          cx={size - 4}
          cy={4}
          r={3}
          fill={OVERDUE_COLOR}
          stroke="white"
          strokeWidth={1}
        />
      )}
    </svg>
  );
}

/** Standalone legend component */
export function HarveyBallLegend({ size = 20 }) {
  return (
    <div className="flex items-center gap-4 text-xs text-slate-600">
      {[0, 1, 2, 3, 4].map((level) => (
        <div key={level} className="flex items-center gap-1.5">
          <HarveyBall level={level} size={size} />
          <span>{LEVEL_LABELS[level]}</span>
        </div>
      ))}
      <div className="flex items-center gap-1.5 ml-2 pl-2 border-l border-slate-300">
        <HarveyBall level={1} required={3} size={size} />
        <span className="text-red-500">Below required</span>
      </div>
      <div className="flex items-center gap-1.5">
        <HarveyBall level={2} overdue size={size} />
        <span className="text-red-500">Overdue</span>
      </div>
    </div>
  );
}

/** Export level labels for use elsewhere */
export { LEVEL_LABELS };
