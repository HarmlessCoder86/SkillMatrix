import { useState } from 'react';
import { useMatrix } from './hooks/useMatrix';
import MatrixGrid from './components/MatrixGrid';
import FilterBar from './components/FilterBar';
import DetailPanel from './components/DetailPanel';

export default function App() {
  const [filters, setFilters] = useState({});
  const [selectedCell, setSelectedCell] = useState(null); // {employeeId, skillId}
  const { data, loading, error, refetch } = useMatrix(filters);

  const handleCellClick = (employeeId, skillId) => {
    setSelectedCell({ employeeId, skillId });
  };

  const handleCloseDetail = () => {
    setSelectedCell(null);
  };

  const handleAssessmentSaved = () => {
    refetch();
  };

  return (
    <div className="min-h-screen bg-matrix-bg">
      {/* ─── Header ─── */}
      <header className="bg-matrix-header text-white px-6 py-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-tight">Skill Matrix</h1>
            <p className="text-sm text-slate-400 mt-0.5">Frontline Skills Management</p>
          </div>
          {data && (
            <span className="text-sm text-slate-400">
              {data.employees.length} employees · {data.categories.reduce((sum, c) => sum + countSkills(c.skills), 0)} skills
            </span>
          )}
        </div>
      </header>

      {/* ─── Filters ─── */}
      <FilterBar filters={filters} onChange={setFilters} />

      {/* ─── Main Content ─── */}
      <main className="px-4 py-4">
        {loading && (
          <div className="flex items-center justify-center h-64 text-slate-400">
            Loading matrix...
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
            Error: {error}
          </div>
        )}

        {data && !loading && (
          <MatrixGrid
            employees={data.employees}
            categories={data.categories}
            assessments={data.assessments}
            categoryCompletion={data.category_completion}
            onCellClick={handleCellClick}
            selectedCell={selectedCell}
          />
        )}
      </main>

      {/* ─── Detail Panel (slide-out) ─── */}
      {selectedCell && (
        <DetailPanel
          employeeId={selectedCell.employeeId}
          skillId={selectedCell.skillId}
          employees={data?.employees || []}
          onClose={handleCloseDetail}
          onSaved={handleAssessmentSaved}
        />
      )}
    </div>
  );
}

/** Recursively count leaf skills */
function countSkills(skills) {
  let count = 0;
  for (const s of skills) {
    if (s.children && s.children.length > 0) {
      count += countSkills(s.children);
    } else {
      count += 1;
    }
  }
  return count;
}
