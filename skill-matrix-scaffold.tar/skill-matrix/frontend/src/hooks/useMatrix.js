import { useState, useEffect, useCallback } from 'react';
import { api } from '../lib/api';

export function useMatrix(filters = {}) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchMatrix = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await api.getMatrix(filters);
      setData(result);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [filters.team_id, filters.supervisor_id]);

  useEffect(() => {
    fetchMatrix();
  }, [fetchMatrix]);

  return { data, loading, error, refetch: fetchMatrix };
}
