/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        matrix: {
          bg: '#f8f9fb',
          header: '#1e293b',
          row: '#ffffff',
          'row-alt': '#f1f5f9',
          border: '#e2e8f0',
          competent: '#22c55e',
          'in-progress': '#f59e0b',
          'not-competent': '#ef4444',
          'not-started': '#94a3b8',
        },
      },
    },
  },
  plugins: [],
}
